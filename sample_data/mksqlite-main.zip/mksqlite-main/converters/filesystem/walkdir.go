package filesystem

// Convert os.WalkDir into a sqlite table.
// Rows will be files and columns will be metadata filepath, filename, mimeType, size, date_created, date_modified.
