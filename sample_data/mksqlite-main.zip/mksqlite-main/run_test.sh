go test -test.fullpath=true -timeout 30s -run ^TestGenTablesNames$ mksqlite/converters
